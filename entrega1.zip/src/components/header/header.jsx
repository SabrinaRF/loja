
export default function Header({nome}) {
    return (
      <nav>
        <p>{nome}</p>
      </nav>  
    );
}